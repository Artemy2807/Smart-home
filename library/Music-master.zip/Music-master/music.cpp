//============IncludeLibrary=============
#include "Arduino.h"
#include "music.h"
#include "pitches.h"
//=========================================TheMorningGreetsUsWithTheDawm==============================
int notesForMorning[] = { NOTE_F5 , NOTE_F5, NOTE_G5 , NOTE_F5 , NOTE_DS5, NOTE_D5, NOTE_C5, NOTE_AS4, NOTE_F4, NOTE_F4,
 NOTE_AS4, NOTE_C5, NOTE_D5, NOTE_DS5, NOTE_D5, NOTE_C5, NOTE_F5, NOTE_F5, NOTE_F5, NOTE_G5, NOTE_F5, NOTE_DS5, NOTE_D5,
 NOTE_C5, NOTE_AS4, NOTE_F4, NOTE_F4, NOTE_DS5, NOTE_D5, NOTE_C5, NOTE_F5, NOTE_D5, NOTE_C5, NOTE_AS4 };
int pauseForMorning[] = { 600, 600, 300, 300, 600, 300, 300, 600, 1200, 600, 600, 300, 300, 600, 300, 300, 1800, 600, 600,
 300, 300, 600, 300, 300, 600, 1200, 600, 600, 300, 300, 600, 300, 300, 5000 };
int noteDurationsForMorning[] = { 300, 300, 150, 150, 450, 150, 150, 450, 450, 450, 450, 150, 150, 450, 150, 150, 1350, 300,
 300, 150, 150, 450, 150, 150, 450, 450, 450, 450, 150, 150, 450, 150, 150, 1350 };
//=================================================SuperMario=========================================
int notesForSuperMario[] = { NOTE_E6, NOTE_E6, NOTE_E6, NOTE_C6, NOTE_E6, NOTE_G6, NOTE_G5, NOTE_C6, NOTE_G5, NOTE_E5,
 NOTE_A5, NOTE_B5, NOTE_AS5, NOTE_A5, NOTE_G5, NOTE_E6, NOTE_G6, NOTE_A6, NOTE_F6, NOTE_G6, NOTE_E6, NOTE_C6, NOTE_D6,
 NOTE_B5, NOTE_C6, NOTE_G5, NOTE_E5, NOTE_A5, NOTE_B5, NOTE_AS5, NOTE_A5, NOTE_G5, NOTE_E6, NOTE_G6, NOTE_A6, NOTE_F6,
 NOTE_G6, NOTE_E6, NOTE_C6, NOTE_D6, NOTE_B5, NOTE_G6, NOTE_FS6, NOTE_F6, NOTE_DS6, NOTE_E6, NOTE_GS5, NOTE_A5, NOTE_C6,
 NOTE_A5, NOTE_C6, NOTE_D6, NOTE_G6, NOTE_FS6, NOTE_F6, NOTE_DS6, NOTE_E6, NOTE_C7, NOTE_C7, NOTE_C7, NOTE_G6, NOTE_FS6,
 NOTE_F6, NOTE_DS6, NOTE_E6, NOTE_GS5, NOTE_A5, NOTE_C6, NOTE_A5, NOTE_C6, NOTE_D6, NOTE_G6, NOTE_FS6, NOTE_F6, NOTE_DS6,
 NOTE_E6, NOTE_C7, NOTE_C7, NOTE_C7, NOTE_C6, NOTE_C6, NOTE_C6, NOTE_C6, NOTE_D6, NOTE_E6, NOTE_C6, NOTE_A5, NOTE_G5, NOTE_C6,
 NOTE_C6, NOTE_C6, NOTE_C6, NOTE_D6, NOTE_E6, NOTE_C6, NOTE_C6, NOTE_C6, NOTE_C6, NOTE_D6, NOTE_E6, NOTE_C6, NOTE_A5, NOTE_G5,
 NOTE_C6, NOTE_C6, NOTE_C6, NOTE_C6, NOTE_D6, NOTE_E6 };
int pauseForSuperMario[] = { 150, 300, 300, 150, 300, 600, 600, 450, 450, 450, 300, 300, 150, 300, 210, 210, 150, 300, 150, 300,
 300, 150, 150, 450, 450, 450, 450, 300, 300, 150, 300  , 210, 210, 150, 300, 150, 300, 300, 150, 150, 600, 150, 150, 150, 300, 300,
 150, 150, 300, 150, 150, 450, 150, 150, 150, 300, 300, 300, 150, 600, 150, 150, 150, 300, 300, 150, 150, 300, 150, 150, 450,
 300, 150, 150, 150, 300, 300, 150, 600, 150, 300, 300, 150, 300, 150, 300, 150, 600, 150, 300, 300, 150, 300, 1350, 150, 300, 300,
 150, 300, 150, 300, 150, 600, 150, 300, 300, 150, 300, 1350 };
int noteDurationsForSuperMario[] = { 150, 300, 150, 150, 300, 600, 600, 450, 150, 300, 300, 150, 150, 300, 210, 210, 150, 300, 150, 150,
 300, 150, 150, 450, 450, 150, 300, 300, 150, 150, 300, 210, 210, 150, 300, 150, 150, 300, 150, 150, 450, 150, 150, 150, 300, 150, 150,
 150, 150, 150, 150, 150, 150, 150, 150, 300, 150, 300, 150, 600,  150, 150, 150, 300, 150, 150, 150, 150, 150, 150, 150, 150, 150, 150, 300,
 150, 300, 150, 600, 150, 300, 150, 150, 300, 150, 300, 150, 600, 150, 300, 150, 150, 300, 150, 150, 300, 150, 150, 300, 150, 300, 150, 600,
 150, 300, 150, 150, 300, 150 };
//===================================================StarWars=========================================
int notesForStarWars[] = { NOTE_G4, NOTE_G4, NOTE_G4, NOTE_DS4, NOTE_AS4, NOTE_G4, NOTE_DS4, NOTE_AS4, NOTE_G4, NOTE_D5, NOTE_D5,
 NOTE_D5, NOTE_DS5, NOTE_AS4, NOTE_FS4, NOTE_DS4, NOTE_AS4, NOTE_G4, NOTE_G5, NOTE_G4, NOTE_G4, NOTE_G5, NOTE_FS5, NOTE_F5, NOTE_E5,
 NOTE_DS5, NOTE_E5, NOTE_GS4, NOTE_CS5, NOTE_C5, NOTE_B4, NOTE_AS4, NOTE_A4, NOTE_AS4, NOTE_DS4, NOTE_FS4, NOTE_DS4, NOTE_AS4, NOTE_G4 };
int noteDurationsForStarWars[] = { 350, 350, 350, 250, 100, 350, 250, 100, 700, 350, 350, 350, 250, 100, 350, 250, 100, 700,
 350, 250, 100, 350, 250, 100, 100, 100, 450, 150, 350, 250, 100, 100, 100, 450, 150, 350, 250, 100, 750 };
//===================================================NokiaTune========================================
int notesForNokiaTune[] = { NOTE_E5, NOTE_D5, NOTE_F4, NOTE_G4, NOTE_C5, NOTE_B4, NOTE_D4, NOTE_E4, NOTE_B4, NOTE_A4, NOTE_C4, NOTE_E4, NOTE_A4 };
int noteDurationsNokiaTune[] = { 125, 125, 250, 250, 125, 125, 250, 250, 125, 125, 250, 250, 1000 };
//===================================================USSRanthem=======================================
int notesForUSSRanthem[] = { NOTE_F3, NOTE_AS3, NOTE_F3, NOTE_G3, NOTE_A3, NOTE_D3, NOTE_D3, NOTE_G3, NOTE_F3, NOTE_DS3, NOTE_F3, NOTE_AS2,
 NOTE_AS2, NOTE_C3, NOTE_C3, NOTE_D3, NOTE_DS3, NOTE_DS3, NOTE_F3, NOTE_G3, NOTE_A3, NOTE_AS3, NOTE_C4, NOTE_F3, NOTE_D4, NOTE_C4, NOTE_AS3, NOTE_C4,
 NOTE_F3, NOTE_F3, NOTE_AS3, NOTE_A3, NOTE_G3, NOTE_A3, NOTE_D3, NOTE_D3, NOTE_G3, NOTE_F3, NOTE_DS3, NOTE_F3, NOTE_AS2, NOTE_AS2, NOTE_AS3, NOTE_A3,
 NOTE_G3, NOTE_F3, NOTE_D4, NOTE_C4, NOTE_AS3, NOTE_A3,  NOTE_AS3, NOTE_C4, NOTE_F3, NOTE_F3, NOTE_AS3, NOTE_A3, NOTE_G3, NOTE_F3, NOTE_G3, NOTE_A3,
 NOTE_D3, NOTE_D3, NOTE_AS3, NOTE_G3, NOTE_A3, NOTE_AS3, NOTE_G3, NOTE_A3, NOTE_AS3, NOTE_G3, NOTE_AS3, NOTE_DS4, NOTE_DS4, NOTE_D4, NOTE_C4, NOTE_AS3,
 NOTE_C4, NOTE_D4, NOTE_AS3, NOTE_AS3, NOTE_C4, NOTE_AS3, NOTE_A3, NOTE_G3, NOTE_A3, NOTE_AS3, NOTE_G3, NOTE_G3, NOTE_AS3, NOTE_A3, NOTE_G3,
 NOTE_F3, NOTE_AS2, NOTE_AS2, NOTE_F3, NOTE_G3, NOTE_A3, NOTE_AS3 };
int pauseForUSSRanthem[] = { 277, 555, 416, 138, 555, 277, 277, 555, 416, 138, 555, 277, 277, 555, 416, 138, 555, 416, 138, 555,
 416, 138, 833, 277, 555, 416, 138, 555, 277, 277, 555, 416, 138, 555, 416, 138, 555, 416, 138, 555, 416, 138, 555, 416, 138, 1111,
 1111, 277, 277, 277, 277, 833, 277, 1111, 1111, 277, 277, 277, 277, 833, 277, 1111, 555, 416, 138, 555, 416, 138, 555, 416, 138,
 1111, 1111, 277, 277, 277, 277, 833, 277, 1111, 1111, 277, 277, 277, 277, 833, 277, 1111, 555, 416, 138, 555, 416, 138, 1111, 555,
 555, 2222 };
int noteDurationsUSSRanthem[] = { 249, 500, 374, 124, 499, 249, 249, 500, 374, 124, 499, 249, 249, 499, 374, 124, 499, 374, 124, 499, 374,
 124, 749, 249, 499, 374, 124, 499, 249, 249, 499, 374, 124, 499, 374, 124, 499, 374, 124, 499, 374, 124, 499, 374, 124, 999, 999, 249,
 249, 249, 249, 749, 249, 999, 999, 249, 249, 249, 249, 749, 249, 999, 499, 374, 124, 499, 374, 124, 499, 374, 124, 999, 999, 249, 249, 249,
 249, 749, 249, 999, 999, 249, 249, 249, 249, 749, 249, 999, 499, 374, 124, 499, 374, 124, 999, 499, 499, 1999 };
//===================================================Herringbone======================================
int notesForHerringbone[] = { NOTE_C4, NOTE_A4, NOTE_A4, NOTE_G4, NOTE_A4, NOTE_F4, NOTE_C4, NOTE_C4, NOTE_C4, NOTE_A4, NOTE_A4, NOTE_AS4,
 NOTE_G4, NOTE_C5, NOTE_C5, NOTE_D4, NOTE_D4, NOTE_AS4,NOTE_AS4,NOTE_A4, NOTE_G4, NOTE_F4, NOTE_C4, NOTE_A4, NOTE_A4, NOTE_G4, NOTE_A4, NOTE_F4 };
int durationsForHerringbone[] = { 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 2, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 2 };
//===================================================HappyNewYear=====================================
int notesForHappyNewYear[] = { NOTE_D4, NOTE_B4, NOTE_A4, NOTE_G4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_B4,  NOTE_A4, NOTE_G4, NOTE_E4,
 NOTE_E4, NOTE_E4, NOTE_C5, NOTE_B4, NOTE_A4, NOTE_D5, NOTE_D5, NOTE_E5, NOTE_D5, NOTE_C5, NOTE_A4, NOTE_B4, NOTE_D4, NOTE_D4, NOTE_B4,
 NOTE_A4,  NOTE_G4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_B4, NOTE_A4, NOTE_G4, NOTE_E4, NOTE_E4, NOTE_E4, NOTE_C5, NOTE_B4,  NOTE_A4,
 NOTE_D5, NOTE_D5, NOTE_D5, NOTE_D5, NOTE_E5, NOTE_D5, NOTE_C5, NOTE_A4, NOTE_G4, NOTE_D5, NOTE_B4, NOTE_B4, NOTE_B4, NOTE_B4, NOTE_B4 , NOTE_B4,
 NOTE_B4, NOTE_D5, NOTE_G4, NOTE_A4, NOTE_B4, NOTE_C5, NOTE_C5, NOTE_C5, NOTE_C5, NOTE_C5, NOTE_B4, NOTE_B4, NOTE_B4, NOTE_B4, NOTE_B4,
 NOTE_A4, NOTE_A4, NOTE_B4, NOTE_A4, NOTE_D5, NOTE_B4, NOTE_B4, NOTE_B4, NOTE_B4, NOTE_B4, NOTE_B4, NOTE_B4, NOTE_D5, NOTE_G4,
 NOTE_A4, NOTE_B4, NOTE_C5, NOTE_C5, NOTE_C5, NOTE_C5, NOTE_C5, NOTE_B4, NOTE_B4, NOTE_B4, NOTE_B4, NOTE_D5, NOTE_D5, NOTE_C5,
 NOTE_A4, NOTE_G4 };
int pauseForHappyNewYear[] = { 250, 250, 250, 250, 750, 250, 250, 250, 250, 250, 750, 250, 250, 250, 250, 250,
 750, 250, 250, 250, 250, 250, 750, 250, 250, 250, 250, 250, 750, 250, 250, 250, 250, 250, 750, 250, 250,
 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 500, 500, 250, 250, 500, 250, 250, 500, 200, 250,
 375, 125, 1000, 250, 250, 375, 125, 250, 250, 250, 125, 125, 250, 250, 250, 250, 500, 500, 250, 250, 500, 250, 250,
 500, 250, 250, 375, 125, 500, 500, 250, 250, 375, 125, 250, 250, 250, 125, 125, 250, 250, 250, 250, 750 };
int noteDurationsHappyNewYear[] = { 225, 225, 225, 225, 450, 225, 225, 225, 225, 225, 450, 225, 225, 225, 225, 225,
 450, 225, 225, 225, 225, 225, 225, 225, 225, 225, 225, 225, 450, 225, 225, 225, 225, 225, 450, 225, 225,
 225, 225, 225, 225, 225, 225, 225, 225, 225, 225, 225, 450, 450, 225, 225, 450, 225, 225, 450, 200, 225,
 337, 112, 450, 225, 225, 337, 125, 225, 225, 225, 112, 112, 225, 225, 225, 225, 500, 500, 225, 225, 450, 225, 225,
 450, 225, 225, 337, 112, 450, 450, 225, 225, 337, 112, 225, 225, 225, 112, 112, 225, 225, 225, 225, 450 };
//===================================================MortalKombat=====================================
int noteForMortalKombat[] = { NOTE_A4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_C5, NOTE_A4, NOTE_A4, NOTE_A4,
 NOTE_A4, NOTE_A4, NOTE_G4, NOTE_G4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_G4, NOTE_C5, NOTE_A4,
 NOTE_A4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_G4, NOTE_C5,
 NOTE_A4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_G4, NOTE_E4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_G4,
 NOTE_C5, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_E5, NOTE_A4,
 NOTE_C5, NOTE_A4, NOTE_AS4, NOTE_A4, NOTE_C5, NOTE_A4, NOTE_AS4, NOTE_G4, NOTE_A4, NOTE_E5, NOTE_A4,
 NOTE_C5, NOTE_A4, NOTE_AS4, NOTE_A4, NOTE_C5, NOTE_A4, NOTE_AS4, NOTE_G4, NOTE_A4, NOTE_E5, NOTE_A4,
 NOTE_C5, NOTE_A4, NOTE_AS4, NOTE_A4, NOTE_C5, NOTE_A4, NOTE_AS4, NOTE_G4, NOTE_A4, NOTE_E5, NOTE_A4,
 NOTE_C5, NOTE_G4, NOTE_G4, NOTE_G4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_E5, NOTE_A4, NOTE_C5, NOTE_A4,
 NOTE_AS4, NOTE_A4, NOTE_C5, NOTE_A4, NOTE_AS4, NOTE_G4, NOTE_A4, NOTE_E5, NOTE_A4, NOTE_C5, NOTE_A4,
 NOTE_AS4, NOTE_A4, NOTE_C5, NOTE_A4, NOTE_AS4, NOTE_G4, NOTE_A4, NOTE_E5, NOTE_A4, NOTE_C5, NOTE_A4,
 NOTE_AS4, NOTE_A4, NOTE_C5, NOTE_A4, NOTE_AS4, NOTE_G4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_G4,
 NOTE_C5, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_G4, NOTE_G4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_A4, 
 NOTE_G4, NOTE_C5, NOTE_A4, NOTE_A4, NOTE_A4};
int pauseForMortalKombat[] = { 274, 274, 274, 274, 182, 182, 273, 273, 273, 273, 182, 182, 273, 273,
 273, 273, 182, 182, 274, 274, 182, 91, 182, 91, 365, 274, 274, 274, 182, 182, 273, 273, 273, 273,
 182, 182, 273, 273, 273, 273, 182, 182, 273, 273, 182, 91, 182, 91, 365, 91, 182, 91, 182, 91, 182,
 91, 182, 91, 91, 182, 91, 182, 91, 182, 91, 182, 91, 182, 91, 91, 182, 91, 182, 91, 182, 91, 182, 
 91, 182, 91, 91, 182, 91, 182, 91, 182, 91, 182, 91, 182, 365, 91, 182, 91, 182, 91, 182, 91, 182, 
 91, 91, 182, 91, 182, 91, 182, 91, 182, 91, 182, 91, 91, 182, 91, 182, 91, 182, 91, 182, 91, 182, 
 91, 91, 13321, 273, 273, 273, 273, 182, 182, 273, 273, 273, 273, 182, 182, 273, 273, 273, 273, 182, 
 182, 273, 273, 122};
int noteDurationForMortalKombat[] = { 164, 164, 164, 164, 109, 109, 164, 164, 164, 164, 109, 109, 164, 164,
 164, 164, 109, 109, 164, 164, 109, 55, 55, 55, 55, 164, 164, 164, 109, 109, 164, 164, 164, 164, 109,
 109, 164, 164, 164, 164, 109, 109, 164, 164, 109, 55, 55, 55, 55, 55, 109, 55, 109, 55, 109, 55, 109,
 55, 55, 109, 55, 109, 55, 109, 55, 109, 55, 109, 55, 55, 109, 55, 109, 55, 109, 55, 109, 55, 109, 55,
 55, 109, 55, 109, 55, 109, 55, 109, 55, 109, 109, 55, 109, 55, 109, 55, 109, 55, 109, 55, 55, 109, 55, 
 109, 55, 109, 55, 109, 55, 109, 55, 55, 109, 55, 109, 55, 109, 55, 109, 55, 109, 55, 55, 109, 164, 
 164, 164, 164, 109, 109, 164, 164, 164, 164, 109, 109, 164, 164, 164, 164, 109, 109, 164, 164, 109};
//=====================================================================================================

Music_P::Music_P(int pinP) {
	this->tonePin = pinP;
}

void Music_P::singTheSong(int frequency, int length, float delayS){
	tone(tonePin, frequency, length);
	delay(delayS);
}

void Music_P::TheMorningGreetsUsWithTheDawm(int repetitions) {
	for (int rep = 0; rep < repetitions; rep++) {
		for (int i = 0; i < (sizeof(notesForMorning)/sizeof(int)); i++){
			singTheSong(notesForMorning[i], noteDurationsForMorning[i], pauseForMorning[i]);
		}
	}
}

void Music_P::SuperMario(int repetitions) {
	for (int rep = 0; rep < repetitions; rep++) {
		for (int i = 0; i < (sizeof(notesForSuperMario)/sizeof(int)); i++) {
			singTheSong(notesForSuperMario[i], noteDurationsForSuperMario[i], pauseForSuperMario[i]);
		}
	}
}

void Music_P::StarWars(int repetitions) {
	for (int rep = 0; rep < repetitions; rep++) {
		for (int i = 0; i < (sizeof(notesForStarWars)/sizeof(int)); i++) {
			singTheSong(notesForStarWars[i], noteDurationsForStarWars[i] * 2, noteDurationsForStarWars[i] * 2);
		}
	}
}

void Music_P::NokiaTune(int repetitions) {
	for (int rep = 0; rep < repetitions; rep++) {
		for (int i = 0; i < (sizeof(notesForNokiaTune)/sizeof(int)); i++) {
			singTheSong(notesForNokiaTune[i], noteDurationsNokiaTune[i], noteDurationsNokiaTune[i]);
		}
	}
}

void Music_P::USSRanthem(int repetitions) {
	for (int rep = 0; rep < repetitions; rep++) {
		for (int i = 0; i < (sizeof(notesForUSSRanthem)/sizeof(int)); i++) {
			singTheSong(notesForUSSRanthem[i], noteDurationsUSSRanthem[i], pauseForUSSRanthem[i]);
		}
	}
}

void Music_P::Herringbone(int repetitions) {
	for (int rep = 0; rep < repetitions; rep++) {
		for (int i = 0; i < (sizeof(notesForHerringbone)/sizeof(int)); i++) {
			singTheSong(notesForHerringbone[i], 1000 / durationsForHerringbone[i], (1000 / durationsForHerringbone[i]) * 1.30);
		}
	}
}

void Music_P::MortalKombat(int repetitions) {
 for(int rep  = 0; rep < repetitions; rep++){
	 for(int i = 0; i < (sizeof(noteForMortalKombat)/sizeof(int)); i++){
		 singTheSong(noteForMortalKombat[i], noteDurationForMortalKombat[i], pauseForMortalKombat[i]);
	 }
 }
}

void Music_P::HappyNewYear(int repetitions) {
	for (int rep = 0; rep < repetitions; rep++) {
		for (int i = 0; i < (sizeof(notesForHappyNewYear)/sizeof(int)); i++) {
			singTheSong(notesForHappyNewYear[i], noteDurationsHappyNewYear[i], pauseForHappyNewYear[i]);
		}
	}
}