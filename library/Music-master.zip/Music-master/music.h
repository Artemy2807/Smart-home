#ifndef MUSIC_h
#define MUSIC_h

#include "Arduino.h"

class Music_P {
private:
	int tonePin;
public:
	Music_P(int pinP);
	void singTheSong(int frequency, int length, float delayS);
	void TheMorningGreetsUsWithTheDawm(int repetitions);
	void SuperMario(int repetitions);
	void StarWars(int repetitions);
	void NokiaTune(int repetitions);
	void USSRanthem(int repetitions);
	void Herringbone(int repetitions);
	void MortalKombat(int repetitions);
	void HappyNewYear(int repetitions);
};

#endif